package com.flowlolo.keyboard.flowlolo

/**
 * FlowLoLo — central config.
 * Sizes are in dp (never px). Colours from PRD Section 2.
 * Tagline: "Speak. It types."
 */
object FlowLoLoConfig {

    // Brand colours (PRD Section 2)
    const val COLOR_INDIGO = 0xFF1E1B4B
    const val COLOR_VIOLET = 0xFF7C3AED
    const val COLOR_LAVENDER = 0xFFF5F3FF
    const val COLOR_MINT = 0xFFE5EEE6
    const val COLOR_HIGHLIGHT_GREEN = 0xFF46745D
    const val COLOR_LISTENING_RED = 0xFFDC2626

    // Keyboard sizes (dp) — PRD Section 4.1
    const val KEY_HEIGHT_DP = 42
    const val KEY_GAP_H_DP = 5
    const val KEY_GAP_V_DP = 6
    const val TOOLBAR_HEIGHT_DP = 44
    const val SUGGESTION_HEIGHT_DP = 34

    const val HEIGHT_COMPACT_DP = 270
    const val HEIGHT_NORMAL_DP = 300 // default
    const val HEIGHT_LARGE_DP = 330

    // Toolbar — 5 items, left to right (PRD 4.3)
    enum class ToolbarItem { AI_FIX, TRANSLATE, MIC, TTS, QUICK_SETTINGS }

    val TOOLBAR_ITEMS: List<ToolbarItem> = listOf(
        ToolbarItem.AI_FIX,
        ToolbarItem.TRANSLATE,
        ToolbarItem.MIC, // centre, violet
        ToolbarItem.TTS,
        ToolbarItem.QUICK_SETTINGS
    )

    // Languages at launch
    enum class Language(val code: String, val label: String) {
        ENGLISH("en", "English"),
        HINDI_DEVANAGARI("hi", "हिन्दी"),
        HINGLISH("hi-Latn", "Hinglish")
    }

    // Hindi layout — owner decision: both, default Phonetic
    enum class HindiLayout { PHONETIC, INSCRIPT }

    // Keyboard mode — RK Influventa Media Business vs Normal
    enum class Mode { NORMAL, BUSINESS }

    // Voice styles (PRD 5.2)
    enum class VoiceStyle {
        CASUAL, NEUTRAL, FORMAL, HINDI_ROMAN, HINDI_DEVANAGARI
    }

    // Speak-in / Write-as (PRD 5.3)
    enum class SpeakIn { AUTO, HINDI, ENGLISH }
    enum class WriteAs { EXACTLY_AS_SPOKEN, DEVANAGARI, HINGLISH_ROMAN, ENGLISH_TRANSLATE }

    // Support (PRD Section 2)
    const val SUPPORT_EMAIL = "guptakrishn258@gmail.com"
    const val RK_WHATSAPP = "+91 6205557860"
    const val RK_EMAIL = "rk.influventa.media@gmail.com"
    const val RK_WEBSITE = "https://rk-influventa-media.pages.dev/"
    const val RK_SOCIAL = "@rkinfluventamedia"
}
