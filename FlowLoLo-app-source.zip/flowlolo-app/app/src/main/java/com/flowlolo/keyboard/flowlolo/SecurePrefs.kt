package com.flowlolo.keyboard.flowlolo

import android.content.Context
import android.content.SharedPreferences

/**
 * API key storage.
 * TODO (Phase 7): migrate to EncryptedSharedPreferences (Keystore-backed, androidx.security).
 * For Phase 0 this uses private SharedPreferences ONLY as a placeholder so the app builds.
 * NEVER store keys in plain prefs in release, never log keys/text/audio.
 * Each user brings their own free key (BYOK). Never ship a key in APK.
 */
class SecurePrefs(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("flowlolo_secure", Context.MODE_PRIVATE)

    fun putApiKey(provider: String, key: String) {
        prefs.edit().putString("key_$provider", key).apply()
    }

    fun getApiKey(provider: String): String? = prefs.getString("key_$provider", null)

    fun removeApiKey(provider: String) {
        prefs.edit().remove("key_$provider").apply()
    }

    fun putEndpoint(provider: String, endpoint: String) {
        prefs.edit().putString("endpoint_$provider", endpoint).apply()
    }

    fun getEndpoint(provider: String): String? = prefs.getString("endpoint_$provider", null)

    fun putModel(provider: String, model: String) {
        prefs.edit().putString("model_$provider", model).apply()
    }

    fun getModel(provider: String): String? = prefs.getString("model_$provider", null)

    fun clearAll() = prefs.edit().clear().apply()
}
