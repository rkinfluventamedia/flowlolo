package com.flowlolo.keyboard.flowlolo

/**
 * RK Influventa Media — 10 voice templates (from templates_rk.md).
 * [Brackets] are spoken/typed fill-ins. NEVER auto-send — user edits then sends.
 * Bodies shown in the RK Templates screen (companion app) and used by voice fill in Phase 3+.
 */
data class RkTemplate(
    val id: String,
    val number: Int,
    val title: String,
    val trigger: String,
    val body: String
)

object RkTemplatesData {

    val ALL: List<RkTemplate> = listOf(
        RkTemplate(
            "brand_outreach", 1, "Brand Outreach", "\"brand outreach bolo\"",
            """Hi [Brand Name] team, I'm Krishn from RK Influventa Media, Ranka. We match AI/tech brands with Instagram micro-creators who can demo your product in Hindi/Hinglish/English.
We handle sourcing, approvals and reporting — one written brief, no post before your written approval.
Can I share a short brief format to understand your audience and deliverables? No commitment needed.
— Team RK Influventa Media | +91 6205557860"""
        ),
        RkTemplate(
            "creator_outreach_dm", 2, "Creator Outreach DM", "\"creator DM likho\"",
            """Hi [Creator Name], I saw your [topic] videos — especially [specific post]. We work with AI/tech brands looking for creators like you.
We check fit first (audience, median views, language) and put terms in writing before you say yes. You're free to decline any brief.
Interested to hear what kind of brands you'd like to work with?
— RK Influventa Media"""
        ),
        RkTemplate(
            "follow_up", 3, "Follow-up", "\"follow-up banao\"",
            """Hi [Name], just following up on my note about [brief/topic]. Happy to share the brief details or pause outreach if timing isn't right.
Let me know what works for you.
— Team RK Influventa Media"""
        ),
        RkTemplate(
            "proposal_cover_note", 4, "Proposal Cover Note", "\"proposal likho\"",
            """Thanks for considering RK Influventa Media. We source Instagram micro-creators for AI/tech brands, manage approvals and report delivery with live links.
Included: creator shortlist with reasons, one written brief, approvals trail, delivery report.
Not included: scripting/production/paid ads. We don't promise views or sales.
Fees depend on scope, usage rights and timing — shared in writing before work starts.
— Krishn Gupta, Founder & CEO | +91 6205557860"""
        ),
        RkTemplate(
            "campaign_brief", 5, "Campaign Brief", "\"brief banao\"",
            """Campaign brief — [Brand/Product]
Audience: [who] | Language: [Hindi/Hinglish/English] | Deliverables: [Reel/Story/Post + count]
Use case to demo: [one feature] | Timeline: [dates] | Usage rights: [ ] | Exclusivity: [ ]
Approval: written final approval required before publish. Ad disclosure required.
Please confirm rates and payment milestones in writing."""
        ),
        RkTemplate(
            "deliverables_checklist", 6, "Deliverables Checklist", "\"checklist do\"",
            """Deliverables checklist:
[ ] Creator confirmed in writing   [ ] Brief signed   [ ] Draft reviewed
[ ] Written final brand approval   [ ] Sponsorship label checked   [ ] Live link captured
[ ] Delivery report shared   [ ] Payment settled as agreed"""
        ),
        RkTemplate(
            "payment_reminder", 7, "Payment Reminder", "\"payment reminder bhejo\"",
            """Hi [Name], gentle reminder on payment for [campaign/deliverable] as per our written terms ([amount/milestone]).
Sharing details again: [ ]. Please let me know if you need anything from our side.
Thank you for working with us.
— Team RK Influventa Media"""
        ),
        RkTemplate(
            "caption_hashtags", 8, "Caption + Hashtags", "\"caption aur hashtags do\"",
            """[One-line hook in Hindi/Hinglish/English]
[What the creator shows in 15 sec]
#AITools #[Niche] #HindiTech #[BrandHashtag] #RKInfluventaMedia
[Ad disclosure line if paid/incentivised]"""
        ),
        RkTemplate(
            "polite_decline", 9, "Polite Decline", "\"polite decline likho\"",
            """Thank you for thinking of us. At this stage we can't take this on — [reason: timing/scope/fit].
Happy to stay in touch for future briefs that match.
Wishing you a great launch.
— Team RK Influventa Media"""
        ),
        RkTemplate(
            "negotiation_reply", 10, "Negotiation Reply", "\"negotiation reply do\"",
            """Thanks for sharing. Our rates depend on scope, usage rights and timing, and we confirm everything in writing before work starts.
Could you share [deliverables, usage period, exclusivity, timeline]? Then I'll confirm what we can do fairly for both sides.
— Krishn Gupta, RK Influventa Media"""
        )
    )

    fun byId(id: String): RkTemplate? = ALL.firstOrNull { it.id == id }

    /** Template for a spoken trigger, e.g. "payment reminder bhejo" -> payment_reminder. */
    fun forSpokenText(spoken: String): RkTemplate? =
        RkTemplates.matchTrigger(spoken)?.let { byId(it) }
}
