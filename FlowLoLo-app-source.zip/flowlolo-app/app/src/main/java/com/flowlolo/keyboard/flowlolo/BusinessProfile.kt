package com.flowlolo.keyboard.flowlolo

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * RK Influventa Media — Business profile.
 * Source: agency_profile_rk.json in assets (from rk-influventa-media.pages.dev).
 * Every field has a safe default — a broken/missing asset must never crash the keyboard.
 */
@Serializable
data class BusinessTeam(
    val founder_ceo: String = "Krishn Gupta",
    val co_founder: String = "Riya Gupta",
    val note: String = ""
)

@Serializable
data class BusinessContact(
    val whatsapp: String = "+91 6205557860",
    val whatsapp_link: String = "https://wa.me/916205557860",
    val email: String = "rk.influventa.media@gmail.com",
    val social: String = "@rkinfluventamedia",
    val support_email_flowlolo: String = "guptakrishn258@gmail.com"
)

@Serializable
data class BusinessProfile(
    val profile_name: String = "RK Influventa Media",
    val business_name: String = "RK INFLUVENTA MEDIA",
    val tagline: String = "We match brands with creators.",
    val one_line: String = "",
    val website: String = "https://rk-influventa-media.pages.dev/",
    val location: String = "Ranka, Jharkhand, India",
    val tone: String = "Professional-friendly, short, clear. Hinglish allowed.",
    val signature: String = "",
    val llm_system_prompt_short: String = "",
    val team: BusinessTeam = BusinessTeam(),
    val contact: BusinessContact = BusinessContact(),
    val services: List<String> = listOf(
        "Creator sourcing — shortlist with a reason for every name",
        "Campaign management — one written brief, approvals trail, publishing calendar",
        "Delivery & reporting — live links, proof of delivery, plain-language readout"
    ),
    val never_rules: List<String> = listOf(
        "Never promise views, sales or income",
        "Never share client names or confidential campaign details without permission",
        "Never post before written final brand approval"
    )
) {
    companion object {
        private val json = Json { ignoreUnknownKeys = true }

        /** Load from assets/agency_profile_rk.json. Returns defaults on failure (never crash keyboard). */
        fun load(context: Context): BusinessProfile {
            return try {
                val text = context.assets.open("agency_profile_rk.json").bufferedReader().use { it.readText() }
                json.decodeFromString(serializer(), text)
            } catch (e: Exception) {
                // Keyboard must never crash because of profile parsing.
                BusinessProfile()
            }
        }

        /** Default profile matching website — used if asset missing. */
        fun defaultRk(): BusinessProfile = BusinessProfile(
            one_line = "Indian influencer marketing agency in Ranka, Jharkhand. We source Instagram micro-creators for AI and tech-tool brands, manage approvals and report what was delivered.",
            signature = "Team RK Influventa Media\nRanka, Jharkhand\nWhatsApp: +91 6205557860 | rk.influventa.media@gmail.com\nhttps://rk-influventa-media.pages.dev/",
            llm_system_prompt_short = "You write for RK INFLUVENTA MEDIA, an Indian influencer marketing agency in Ranka, Jharkhand that matches AI/SaaS/tech brands with Instagram micro-creators (mainly Hindi, also Hinglish/English). Services: creator sourcing, campaign management, delivery & reporting. Tone: professional-friendly, short. Reply in the language of the incoming message. Never promise views/sales/income. Never share client names. No post before written approval. Never auto-send."
        )
    }
}

/** Voice-trigger map (spoken words -> template id). See RkTemplatesData for full bodies. */
object RkTemplates {
    val TRIGGERS: Map<String, String> = mapOf(
        "brand outreach" to "brand_outreach",
        "creator dm" to "creator_outreach_dm",
        "follow-up" to "follow_up",
        "proposal" to "proposal_cover_note",
        "brief" to "campaign_brief",
        "checklist" to "deliverables_checklist",
        "payment reminder" to "payment_reminder",
        "caption" to "caption_hashtags",
        "polite decline" to "polite_decline",
        "negotiation" to "negotiation_reply"
    )

    fun matchTrigger(spoken: String): String? {
        val lower = spoken.lowercase()
        return TRIGGERS.entries.firstOrNull { lower.contains(it.key) }?.value
    }
}
