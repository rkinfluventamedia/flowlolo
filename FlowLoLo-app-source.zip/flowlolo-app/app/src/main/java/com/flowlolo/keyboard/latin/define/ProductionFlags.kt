/*
 * Copyright (C) 2012 The Android Open Source Project
 * modified
 * SPDX-License-Identifier: Apache-2.0 AND GPL-3.0-only
 */

package com.flowlolo.keyboard.latin.define

object ProductionFlags {
    /**
     * Include all suggestions from all dictionaries in
     * [com.flowlolo.keyboard.latin.SuggestedWords.mRawSuggestions].
     */
    const val INCLUDE_RAW_SUGGESTIONS = false
}
