package com.flowlolo.keyboard.flowlolo

/**
 * Engine layer — PRD Section 6.
 * Exactly one active provider per slot. Adding a provider must not touch UI code.
 * Phase 0: interfaces + router only. Implementations come in Phase 3-6.
 * No typed text, audio, or API keys in logs — ever.
 */

sealed interface EngineResult<out T> {
    data class Success<T>(val value: T) : EngineResult<T>
    data class Failure(val message: String, val code: Int? = null) : EngineResult<Nothing>
    data object NotConfigured : EngineResult<Nothing>
    data object OfflineOnly : EngineResult<Nothing>
}

enum class EngineKind { ONLINE, OFFLINE }

interface SttEngine {
    val kind: EngineKind
    val name: String
    suspend fun transcribe(audioPath: String, language: String): EngineResult<String>
}

interface LlmEngine {
    val kind: EngineKind
    val name: String
    suspend fun complete(systemPrompt: String, userText: String, maxTokens: Int = 512): EngineResult<String>
    suspend fun fixGrammar(text: String, style: FlowLoLoConfig.VoiceStyle): EngineResult<String> =
        complete("Fix grammar and punctuation. Keep meaning. Short.", text)
    suspend fun translate(text: String, targetLanguage: String): EngineResult<String> =
        complete("Translate to $targetLanguage. Keep tone.", text)
}

interface TtsEngine {
    val kind: EngineKind
    val name: String
    suspend fun speak(text: String, language: String): EngineResult<Unit>
    fun stop()
}

/**
 * Picks active engine per slot. Order: preferred -> failover on 429/timeout -> offline.
 * Auto-fallback only if user turns it on. Offline-only blocks every network call.
 */
class EngineRouter(
    var stt: SttEngine? = null,
    var llm: LlmEngine? = null,
    var tts: TtsEngine? = null,
    var offlineOnly: Boolean = false,
    var autoFallback: Boolean = false
) {
    fun canUseOnline(): Boolean = !offlineOnly

    suspend fun transcribe(audioPath: String, language: String): EngineResult<String> {
        val engine = stt ?: return EngineResult.NotConfigured
        if (engine.kind == EngineKind.ONLINE && offlineOnly) return EngineResult.OfflineOnly
        return engine.transcribe(audioPath, language)
    }

    suspend fun complete(systemPrompt: String, userText: String): EngineResult<String> {
        val engine = llm ?: return EngineResult.NotConfigured
        if (engine.kind == EngineKind.ONLINE && offlineOnly) return EngineResult.OfflineOnly
        return engine.complete(systemPrompt, userText)
    }

    suspend fun speak(text: String, language: String): EngineResult<Unit> {
        val engine = tts ?: return EngineResult.NotConfigured
        if (engine.kind == EngineKind.ONLINE && offlineOnly) return EngineResult.OfflineOnly
        return engine.speak(text, language)
    }
}

// ---- Stub implementations (Phase 3+ will replace with Groq/OpenRouter/sherpa-onnx) ----

class StubSttEngine(override val kind: EngineKind, override val name: String) : SttEngine {
    override suspend fun transcribe(audioPath: String, language: String): EngineResult<String> =
        EngineResult.Failure("STT engine not implemented yet — Phase 3")
}

class StubLlmEngine(override val kind: EngineKind, override val name: String) : LlmEngine {
    override suspend fun complete(systemPrompt: String, userText: String, maxTokens: Int): EngineResult<String> =
        EngineResult.Failure("LLM engine not implemented yet — Phase 4")
}

class StubTtsEngine(override val kind: EngineKind, override val name: String) : TtsEngine {
    override suspend fun speak(text: String, language: String): EngineResult<Unit> =
        EngineResult.Failure("TTS engine not implemented yet — Phase 4/6")
    override fun stop() = Unit
}
