package com.flowlolo.keyboard.flowlolo

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * FlowLoLo companion app — Home.
 * Material 3 + Compose, FlowLoLo brand theme. Single launcher entry.
 * Setup checklist reads REAL system state (enabled + selected) and refreshes on resume.
 */
class FlowLoLoHomeActivity : ComponentActivity() {

    private val setupState = mutableStateOf(SetupState(false, false))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val profile = BusinessProfile.load(this)
        setContent {
            FlowLoLoTheme {
                FlowLoLoHomeScreen(
                    profile = profile,
                    setup = setupState.value,
                    onEnableKeyboard = { openEnableKeyboardSettings() },
                    onOpenKeyboardSettings = { openKeyboardSettings() },
                    onOpenTemplates = { openTemplates() },
                    onWhatsApp = { openWhatsApp(profile.contact.whatsapp_link) }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        setupState.value = readSetupState()
    }

    private fun readSetupState(): SetupState {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_INPUT_METHODS
        ) ?: ""
        val default = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
        return SetupStatus.compute(enabled, default, packageName)
    }

    private fun openEnableKeyboardSettings() {
        try {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        } catch (_: Exception) {
            // Some devices lack the settings activity — never crash.
        }
    }

    private fun openTemplates() {
        try {
            startActivity(Intent(this, FlowLoLoTemplatesActivity::class.java))
        } catch (_: Exception) {
            // never crash
        }
    }

    private fun openWhatsApp(link: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(link)))
        } catch (_: Exception) {
            // WhatsApp/browser missing — never crash
        }
    }

    private fun openKeyboardSettings() {
        try {
            // String class-name avoids a hard compile-time dependency; class is in the same APK.
            startActivity(Intent().setClassName(packageName, "com.flowlolo.keyboard.settings.SettingsActivity"))
        } catch (_: Exception) {
            // Settings activity missing/unavailable — fall back to system IME settings. Never crash.
            openEnableKeyboardSettings()
        }
    }
}

@Composable
fun FlowLoLoHomeScreen(
    profile: BusinessProfile,
    setup: SetupState,
    onEnableKeyboard: () -> Unit,
    onOpenKeyboardSettings: () -> Unit,
    onOpenTemplates: () -> Unit,
    onWhatsApp: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        BrandHeader()
        SetupCard(setup, onEnableKeyboard, onOpenKeyboardSettings)
        ReadyCard()
        BusinessCard(profile, onOpenTemplates, onWhatsApp)
        Footer()
    }
}

@Composable
private fun BrandHeader() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(
                    Brush.linearGradient(
                        listOf(FlowLoLoColors.Violet, FlowLoLoColors.Indigo)
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            // brand monogram — matches the new launcher icon (F + flow)
            Text("F", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
        }
        Spacer(Modifier.width(14.dp))
        Column {
            Text("FlowLoLo", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
            Text(
                "Speak. It types.",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
private fun SetupCard(
    setup: SetupState,
    onEnableKeyboard: () -> Unit,
    onOpenKeyboardSettings: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Get started", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

            StepRow("1", "Enable FlowLoLo in system keyboards", setup.enabledInSystem)
            StepRow("2", "Switch to FlowLoLo while typing", setup.selectedAsCurrent)
            StepRow("3", "Speak — voice types for you", false, "Phase 3")

            // progress bar (custom, no experimental API)
            val progress = listOf(setup.enabledInSystem, setup.selectedAsCurrent).count { it } / 2f
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(progress)
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(FlowLoLoColors.Violet, FlowLoLoColors.Green)
                            )
                        )
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onEnableKeyboard, modifier = Modifier.weight(1f)) {
                    Text(if (setup.allDone) "Manage keyboards" else "Enable keyboard")
                }
                OutlinedButton(onClick = onOpenKeyboardSettings, modifier = Modifier.weight(1f)) {
                    Text("Keyboard settings")
                }
            }
        }
    }
}

@Composable
private fun StepRow(number: String, label: String, done: Boolean, tag: String? = null) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(26.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(
                    when {
                        done -> MaterialTheme.colorScheme.secondary
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                if (done) "✓" else number,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = if (done) MaterialTheme.colorScheme.onSecondary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.width(10.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        if (tag != null) {
            Text(
                tag,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = soonColor()
            )
        }
    }
}

@Composable
private fun ReadyCard() {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Inside your keyboard", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            ReadyRow(true, "English typing with autocorrect + suggestions")
            ReadyRow(true, "Emoji keyboard + emoji search")
            ReadyRow(true, "Swipe (gesture) typing")
            ReadyRow(true, "Hindi — Phonetic (default) + InScript")
            ReadyRow(true, "Hinglish support, clipboard, themes")
            ReadyRow(false, "Voice typing (online) — Phase 3")
            ReadyRow(false, "AI Fix · Translate · Read aloud — Phase 4")
            ReadyRow(false, "Offline voice + models on demand — Phase 5")
        }
    }
}

@Composable
private fun ReadyRow(ready: Boolean, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            if (ready) "✓" else "🕐",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = if (ready) readyColor() else soonColor(),
            modifier = Modifier.width(24.dp)
        )
        Text(label, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun BusinessCard(profile: BusinessProfile, onOpenTemplates: () -> Unit, onWhatsApp: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = mintContainer())
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🏢", fontSize = 18.sp)
                Spacer(Modifier.width(8.dp))
                Column {
                    Text(
                        profile.business_name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        profile.tagline,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Text(
                profile.one_line.ifBlank { profile.tagline },
                style = MaterialTheme.typography.bodyMedium
            )

            // team
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("👥 ", fontSize = 13.sp)
                Text(
                    "${profile.team.founder_ceo} — Founder & CEO  ·  ${profile.team.co_founder} — Co-founder",
                    fontSize = 13.sp, fontWeight = FontWeight.SemiBold
                )
            }

            // services
            Text("SERVICES", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = readyColor())
            profile.services.forEach { svc ->
                Row {
                    Text("▸  ", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    Text(svc, fontSize = 12.sp)
                }
            }

            // contact
            Text("CONTACT", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = readyColor())
            ContactRow("📞", profile.contact.whatsapp)
            ContactRow("✉️", profile.contact.email)
            ContactRow("📸", profile.contact.social)
            ContactRow("🌐", profile.website)

            // never rules
            Text("NEVER (business rules)", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.error)
            profile.never_rules.forEach {
                Text("• $it", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
            }

            Text(
                "BUSINESS MODE LOADED · auto-on when you speak",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = readyColor()
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onOpenTemplates, modifier = Modifier.weight(1f)) {
                    Text("📋 RK Templates")
                }
                OutlinedButton(onClick = onWhatsApp, modifier = Modifier.weight(1f)) {
                    Text("WhatsApp")
                }
            }
        }
    }
}

@Composable
private fun ContactRow(icon: String, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("$icon  ", fontSize = 12.sp)
        Text(text, fontSize = 12.sp)
    }
}

@Composable
private fun Footer() {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "Support: ${FlowLoLoConfig.SUPPORT_EMAIL}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            "GPL-3.0 · built on HeliBoard",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
