package com.flowlolo.keyboard.flowlolo

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * NEW FEATURE — RK Templates browser.
 * All 10 agency templates: tap to open, Copy, Share, WhatsApp.
 * Phase 3 will fill [brackets] by voice; today you copy/edit/send manually (never auto-send).
 */
class FlowLoLoTemplatesActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val profile = BusinessProfile.load(this)
        setContent {
            FlowLoLoTheme {
                TemplatesScreen(
                    profile = profile,
                    onBack = { finish() }
                )
            }
        }
    }
}

@Composable
fun TemplatesScreen(profile: BusinessProfile, onBack: () -> Unit) {
    val context = LocalContext.current
    val selectedId = androidx.compose.runtime.remember { mutableStateOf<String?>(RkTemplatesData.ALL.first().id) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Brush.linearGradient(listOf(FlowLoLoColors.Green, FlowLoLoColors.Indigo))),
                contentAlignment = Alignment.Center
            ) { Text("📋", fontSize = 20.sp) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("RK Templates", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                Text(
                    "10 ready messages · bolne wala trigger Phase 3 mein",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            OutlinedButton(onClick = onBack) { Text("Back") }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            RkTemplatesData.ALL.forEach { tpl ->
                val open = selectedId.value == tpl.id
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedId.value = if (open) null else tpl.id },
                    colors = CardDefaults.cardColors(
                        containerColor = if (open) mintContainer() else MaterialTheme.colorScheme.surface
                    )
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(30.dp)
                                    .clip(RoundedCornerShape(9.dp))
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    tpl.number.toString(),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(tpl.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Text(
                                    tpl.trigger,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Text(if (open) "▾" else "▸", fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        if (open) {
                            Text(
                                tpl.body,
                                fontSize = 13.sp,
                                lineHeight = 19.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                        cm?.setPrimaryClip(ClipData.newPlainText("flowlolo_template", tpl.body))
                                    },
                                    modifier = Modifier.weight(1f)
                                ) { Text("📋 Copy") }
                                OutlinedButton(
                                    onClick = {
                                        val send = Intent(Intent.ACTION_SEND).apply {
                                            type = "text/plain"
                                            putExtra(Intent.EXTRA_TEXT, tpl.body)
                                        }
                                        try {
                                            context.startActivity(Intent.createChooser(send, "Share template"))
                                        } catch (_: Exception) { /* never crash */ }
                                    },
                                    modifier = Modifier.weight(1f)
                                ) { Text("↗ Share") }
                            }
                        }
                    }
                }
            }

            // rules footer
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = mintContainer())
            ) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("RULES — hamesha", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = readyColor())
                    profile.never_rules.forEach {
                        Text("• $it", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                    }
                    Text(
                        "Kabhi auto-send nahi — pehle edit karo, phir khud bhejo.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
