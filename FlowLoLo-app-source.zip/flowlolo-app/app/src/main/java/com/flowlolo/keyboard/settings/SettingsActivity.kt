// SPDX-License-Identifier: GPL-3.0-only
package com.flowlolo.keyboard.settings

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.lifecycleScope
import com.flowlolo.keyboard.compat.locale
import com.flowlolo.keyboard.keyboard.KeyboardSwitcher
import com.flowlolo.keyboard.keyboard.internal.KeyboardIconsSet
import com.flowlolo.keyboard.latin.BuildConfig
import com.flowlolo.keyboard.latin.InputAttributes
import com.flowlolo.keyboard.latin.R
import com.flowlolo.keyboard.latin.common.FileUtils
import com.flowlolo.keyboard.latin.define.DebugFlags
import com.flowlolo.keyboard.latin.dictionary.cleanUnusedMainDicts
import com.flowlolo.keyboard.latin.settings.Settings
import com.flowlolo.keyboard.latin.utils.BackButton
import com.flowlolo.keyboard.latin.utils.DeviceProtectedUtils
import com.flowlolo.keyboard.latin.utils.GestureDataGatheringSettings
import com.flowlolo.keyboard.latin.utils.IntentUtils
import com.flowlolo.keyboard.latin.utils.JniUtils
import com.flowlolo.keyboard.latin.utils.Theme
import com.flowlolo.keyboard.latin.utils.UncachedInputMethodManagerUtils
import com.flowlolo.keyboard.latin.utils.prefs
import com.flowlolo.keyboard.settings.dialogs.ConfirmationDialog
import com.flowlolo.keyboard.settings.dialogs.NewDictionaryDialog
import com.flowlolo.keyboard.settings.screens.gesturedata.END_DATE_EPOCH_MILLIS
import com.flowlolo.keyboard.settings.screens.gesturedata.TWO_WEEKS_IN_MILLIS
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

open class SettingsActivity : ComponentActivity(), SharedPreferences.OnSharedPreferenceChangeListener {
    private val prefs by lazy { this.prefs() }
    val prefChanged = MutableStateFlow(0) // simple counter, as the only relevant information is that something changed
    fun prefChanged() = prefChanged.value++
    private val dictUriFlow = MutableStateFlow<Uri?>(null)
    private val cachedDictionaryFile by lazy { File(this.cacheDir.path + File.separator + "temp_dict") }
    private val crashReportFiles = MutableStateFlow<List<File>>(emptyList())
    private var paused = true

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ctx: Context = this
        val cvDeferred = lifecycleScope.async(Dispatchers.Default) { ComposeView(context = ctx) }
        val jobs = mutableListOf(
            lifecycleScope.launch(Dispatchers.Default) { settingsContainer = SettingsContainer(ctx) },
            lifecycleScope.launch(Dispatchers.Default) {
                if (Settings.getValues() != null) return@launch
                val inputAttributes = InputAttributes(EditorInfo(), false, packageName)
                Settings.getInstance().loadSettings(ctx, resources.configuration.locale(), inputAttributes)
            },
            lifecycleScope.launch(Dispatchers.Default) { setContentView(cvDeferred.await()) },
            lifecycleScope.launch(Dispatchers.IO) { cleanUnusedMainDicts(ctx) },
            lifecycleScope.launch(Dispatchers.IO) {
                crashReportFiles.value = findCrashReports(!BuildConfig.DEBUG && !DebugFlags.DEBUG_ENABLED)
            }
        )
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        if (!UncachedInputMethodManagerUtils.isThisImeCurrent(this, imm))
            jobs.add(lifecycleScope.launch(Dispatchers.Default) { KeyboardIconsSet.instance.loadIcons(ctx) }) // otherwise we may crash when displaying toolbar keys

        val spellchecker = intent?.getBooleanExtra("spellchecker", false) ?: false

        val cv = runBlocking { cvDeferred.await() }
        runBlocking { jobs.joinAll() }
        cv.setContent {
            Theme {
                Surface {
                    val dictUri by dictUriFlow.collectAsState()
                    val crashReports by crashReportFiles.collectAsState()
                    val crashFilePicker = filePicker { saveCrashReports(it) }
                    var showWelcomeWizard by rememberSaveable { mutableStateOf(
                        !UncachedInputMethodManagerUtils.isThisImeCurrent(this, imm)
                                || !UncachedInputMethodManagerUtils.isThisImeEnabled(this, imm)
                    ) }
                    if (spellchecker)
                        Scaffold(contentWindowInsets = WindowInsets.safeDrawing) { innerPadding ->
                            Column(Modifier.padding(innerPadding)) {
                                TopAppBar(
                                    title = { Text(stringResource(R.string.android_spell_checker_settings)) },
                                    windowInsets = WindowInsets(0),
                                    navigationIcon = {
                                        BackButton { this@SettingsActivity.finish() }
                                    },
                                )
                                settingsContainer[Settings.PREF_USE_CONTACTS]!!.Preference()
                                settingsContainer[Settings.PREF_USE_APPS]!!.Preference()
                                settingsContainer[Settings.PREF_BLOCK_POTENTIALLY_OFFENSIVE]!!.Preference()
                                settingsContainer[Settings.PREF_SPELLCHECK_SUGGEST]!!.Preference()
                            }
                        }
                    else if (showWelcomeWizard) {
                        WelcomeWizard(close = { showWelcomeWizard = false }, finish = this::finish)
                    } else {
                        SettingsNavHost(onClickBack = { this.finish() })
                        if (crashReports.isNotEmpty()) {
                            val ctx = LocalContext.current
                            ConfirmationDialog(
                                cancelButtonText = "ignore",
                                onDismissRequest = { crashReportFiles.value = emptyList() },
                                neutralButtonText = "delete",
                                onNeutral = { crashReports.forEach { it.delete() }; crashReportFiles.value = emptyList() },
                                confirmButtonText = "get",
                                onConfirmed = {
                                    val intent = IntentUtils.getResolvableTypeIntent(ctx, "application/zip")
                                        .setAction(Intent.ACTION_CREATE_DOCUMENT)
                                        .putExtra(Intent.EXTRA_TITLE, "crash_reports.zip")
                                    crashFilePicker.launch(intent)
                                },
                                content = { Text("Crash report files found") },
                            )
                        } else if (JniUtils.sHaveGestureLib && System.currentTimeMillis() < END_DATE_EPOCH_MILLIS + TWO_WEEKS_IN_MILLIS) {
                            GestureDataGatheringSettings.GestureDataPromotionReminderDialog()
                        }
                    }
                    if (dictUri != null) {
                        NewDictionaryDialog(
                            onDismissRequest = { dictUriFlow.value = null },
                            cachedFile = cachedDictionaryFile,
                            mainLocale = null
                        )
                    }
                }
            }
        }

        if (intent?.action == Intent.ACTION_VIEW) {
            intent?.data?.let {
                cachedDictionaryFile.delete()
                FileUtils.copyContentUriToNewFile(it, this, cachedDictionaryFile)
                dictUriFlow.value = it
            }
            intent = null
        }

        enableEdgeToEdge()
    }

    override fun onStart() {
        super.onStart()
        prefs.registerOnSharedPreferenceChangeListener(this)
    }

    override fun onStop() {
        prefs.unregisterOnSharedPreferenceChangeListener(this)
        super.onStop()
    }

    override fun onPause() {
        super.onPause()
        setForceTheme(null, null)
        paused = true
    }

    override fun onResume() {
        super.onResume()
        paused = false
    }

    fun setForceTheme(theme: String?, night: Boolean?) {
        if (paused) return
        if (forceTheme == theme && forceNight == night)
            return
        forceTheme = theme
        forceNight = night
        KeyboardSwitcher.getInstance().setThemeNeedsReload()
    }

    private fun findCrashReports(onlyUnprotected: Boolean): List<File> {
        val unprotected = DeviceProtectedUtils.getFilesDir(this)?.listFiles().orEmpty()
        if (onlyUnprotected)
            return unprotected.filter { it.name.startsWith("crash_report") }

        val dir = getExternalFilesDir(null)
        val allFiles = dir?.listFiles()?.toList().orEmpty() + unprotected
        return allFiles.filter { it.name.startsWith("crash_report") }
    }

    private fun saveCrashReports(uri: Uri) {
        val files = findCrashReports(false)
        if (files.isEmpty()) return
        runCatching {
            contentResolver.openOutputStream(uri)?.use {
                val bos = BufferedOutputStream(it)
                val z = ZipOutputStream(bos)
                for (file in files) {
                    val f = FileInputStream(file)
                    z.putNextEntry(ZipEntry(file.name))
                    FileUtils.copyStreamToOtherStream(f, z)
                    f.close()
                    z.closeEntry()
                }
                z.close()
                bos.close()
                for (file in files) {
                    file.delete()
                }
            }
        }
    }

    companion object {
        // public write so compose previews can show the screens
        // having it in a companion object is not ideal as it will stay in memory even after settings are closed
        // but it's small enough to not care
        lateinit var settingsContainer: SettingsContainer

        var forceNight: Boolean? = null
        var forceTheme: String? = null
    }

    override fun onSharedPreferenceChanged(prefereces: SharedPreferences?, key: String?) {
        prefChanged()
    }
}

// duplicate of SettingsActivity so we can launch it when the app icon is disabled in Android 9 and older
class SettingsActivity2 : SettingsActivity()
