package com.flowlolo.keyboard.flowlolo

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/**
 * FlowLoLo brand theme — PRD Section 2.
 * Indigo base, violet primary, lavender background, mint secondary.
 * Used by the companion app (Compose). Keyboard themes stay HeliBoard's (untouched core).
 */
object FlowLoLoColors {
    val Indigo = Color(0xFF1E1B4B)
    val IndigoDarkBg = Color(0xFF14122E)
    val IndigoSurface = Color(0xFF1C1940)
    val Violet = Color(0xFF7C3AED)
    val VioletLight = Color(0xFFA78BFA)
    val Lavender = Color(0xFFF5F3FF)
    val Mint = Color(0xFFE5EEE6)
    val MintDarkContainer = Color(0xFF233327)
    val Green = Color(0xFF46745D)
    val GreenBright = Color(0xFF8FBF9F)
    val Red = Color(0xFFDC2626)
    val RedBright = Color(0xFFF87171)
    val AmberLight = Color(0xFFB45309)
    val AmberDark = Color(0xFFFBBF24)
}

private val LightScheme = lightColorScheme(
    primary = FlowLoLoColors.Violet,
    onPrimary = Color.White,
    primaryContainer = FlowLoLoColors.Lavender,
    onPrimaryContainer = FlowLoLoColors.Indigo,
    secondary = FlowLoLoColors.Green,
    onSecondary = Color.White,
    secondaryContainer = FlowLoLoColors.Mint,
    onSecondaryContainer = FlowLoLoColors.Indigo,
    tertiary = FlowLoLoColors.VioletLight,
    background = Color(0xFFF7F6FE),
    onBackground = FlowLoLoColors.Indigo,
    surface = Color.White,
    onSurface = FlowLoLoColors.Indigo,
    surfaceVariant = FlowLoLoColors.Lavender,
    onSurfaceVariant = Color(0xFF4A4766),
    outline = Color(0xFF8B88A8),
    error = FlowLoLoColors.Red,
    onError = Color.White
)

private val DarkScheme = darkColorScheme(
    primary = FlowLoLoColors.VioletLight,
    onPrimary = FlowLoLoColors.Indigo,
    primaryContainer = Color(0xFF3B2D7A),
    onPrimaryContainer = Color(0xFFE9E4FF),
    secondary = FlowLoLoColors.GreenBright,
    onSecondary = Color(0xFF12281A),
    secondaryContainer = FlowLoLoColors.MintDarkContainer,
    onSecondaryContainer = FlowLoLoColors.Mint,
    tertiary = FlowLoLoColors.Violet,
    background = FlowLoLoColors.IndigoDarkBg,
    onBackground = Color(0xFFE9E4FF),
    surface = FlowLoLoColors.IndigoSurface,
    onSurface = Color(0xFFE9E4FF),
    surfaceVariant = Color(0xFF2A2652),
    onSurfaceVariant = Color(0xFFB9B4D6),
    outline = Color(0xFF6F6B8F),
    error = FlowLoLoColors.RedBright,
    onError = FlowLoLoColors.Indigo
)

@Composable
fun FlowLoLoTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkScheme else LightScheme,
        content = content
    )
}

/** Mint card container that adapts to dark mode. */
@Composable
fun mintContainer(): Color =
    if (isSystemInDarkTheme()) FlowLoLoColors.MintDarkContainer else FlowLoLoColors.Mint

/** Ready green that adapts to dark mode. */
@Composable
fun readyColor(): Color =
    if (isSystemInDarkTheme()) FlowLoLoColors.GreenBright else FlowLoLoColors.Green

/** "Coming soon" amber that adapts to dark mode. */
@Composable
fun soonColor(): Color =
    if (isSystemInDarkTheme()) FlowLoLoColors.AmberDark else FlowLoLoColors.AmberLight
