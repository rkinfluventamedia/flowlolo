// SPDX-License-Identifier: GPL-3.0-only
package com.flowlolo.keyboard.latin

enum class InputStyle {
    NONE, TYPING, UPDATE_BATCH, TAIL_BATCH, APPLICATION_SPECIFIED, RECORRECTION, PREDICTION, BEGINNING_OF_SENTENCE_PREDICTION
}
