package com.flowlolo.keyboard.flowlolo

/**
 * Setup status — pure logic, JVM-testable (no Android imports on purpose).
 * The activity reads system settings and passes raw strings here.
 */
data class SetupState(
    val enabledInSystem: Boolean,   // step 1: FlowLoLo listed in system keyboards
    val selectedAsCurrent: Boolean  // step 2: FlowLoLo is the keyboard in use
) {
    val allDone: Boolean get() = enabledInSystem && selectedAsCurrent
}

object SetupStatus {

    /**
     * enabledInputMethods = Settings.Secure.ENABLED_INPUT_METHODS
     * Format: "pkg1/.ImeA:pkg2/.ImeB:..." (colon-separated ComponentNames)
     */
    fun isKeyboardEnabled(enabledInputMethods: String, packageName: String): Boolean {
        return enabledInputMethods.split(":").any { entry ->
            val pkg = entry.substringBefore("/").trim()
            pkg == packageName && entry.trim().contains("/")
        }
    }

    /**
     * defaultInputMethod = Settings.Secure.DEFAULT_INPUT_METHOD
     * Format: "pkg/.Ime" or null/blank if none.
     */
    fun isKeyboardSelected(defaultInputMethod: String?, packageName: String): Boolean {
        if (defaultInputMethod.isNullOrBlank()) return false
        return defaultInputMethod.substringBefore("/").trim() == packageName
    }

    fun compute(
        enabledInputMethods: String,
        defaultInputMethod: String?,
        packageName: String
    ): SetupState = SetupState(
        enabledInSystem = isKeyboardEnabled(enabledInputMethods, packageName),
        selectedAsCurrent = isKeyboardSelected(defaultInputMethod, packageName)
    )
}
