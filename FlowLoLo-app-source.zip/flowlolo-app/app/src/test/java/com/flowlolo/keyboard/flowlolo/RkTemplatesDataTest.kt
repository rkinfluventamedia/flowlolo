package com.flowlolo.keyboard.flowlolo

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RkTemplatesDataTest {

    @Test
    fun allTenTemplatesPresent() {
        assertEquals(10, RkTemplatesData.ALL.size)
        assertEquals(listOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10), RkTemplatesData.ALL.map { it.number })
    }

    @Test
    fun everyTemplateHasBodyAndTrigger() {
        RkTemplatesData.ALL.forEach { t ->
            assertTrue("body empty: ${t.id}", t.body.isNotBlank())
            assertTrue("trigger empty: ${t.id}", t.trigger.isNotBlank())
            assertTrue("title empty: ${t.id}", t.title.isNotBlank())
        }
    }

    @Test
    fun idsMatchTriggerMap() {
        RkTemplates.TRIGGERS.values.forEach { id ->
            assertNotNull("trigger id missing in data: $id", RkTemplatesData.byId(id))
        }
    }

    @Test
    fun spokenTextFindsTemplate() {
        assertEquals("payment_reminder", RkTemplatesData.forSpokenText("payment reminder bhejo")?.id)
        assertEquals("brand_outreach", RkTemplatesData.forSpokenText("ek brand outreach bana do")?.id)
        assertEquals(null, RkTemplatesData.forSpokenText("kuch aur bolo"))
    }

    @Test
    fun signatureTemplateHasContact() {
        val t = RkTemplatesData.byId("brand_outreach")!!
        assertTrue(t.body.contains("Krishn"))
        assertTrue(t.body.contains("RK Influventa Media"))
    }

    @Test
    fun teamAndContactDefaults() {
        val p = BusinessProfile.defaultRk()
        assertEquals("Krishn Gupta", p.team.founder_ceo)
        assertEquals("Riya Gupta", p.team.co_founder)
        assertTrue(p.contact.whatsapp_link.startsWith("https://wa.me/"))
        assertEquals(3, p.services.size)
        assertTrue(p.never_rules.any { it.contains("Never promise views") })
    }
}
