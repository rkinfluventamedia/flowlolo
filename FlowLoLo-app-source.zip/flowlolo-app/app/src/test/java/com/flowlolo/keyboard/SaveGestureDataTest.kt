package com.flowlolo.keyboard

import com.flowlolo.keyboard.keyboard.Keyboard
import com.flowlolo.keyboard.keyboard.KeyboardElement
import com.flowlolo.keyboard.keyboard.KeyboardLayoutSet
import com.flowlolo.keyboard.keyboard.internal.KeyboardParams
import com.flowlolo.keyboard.latin.InputStyle
import com.flowlolo.keyboard.latin.LatinIME
import com.flowlolo.keyboard.latin.NgramContext
import com.flowlolo.keyboard.latin.common.ComposedData
import com.flowlolo.keyboard.latin.common.InputPointers
import com.flowlolo.keyboard.latin.dictionary.Dictionary
import com.flowlolo.keyboard.latin.suggestions.SuggestedWordInfo
import com.flowlolo.keyboard.latin.suggestions.SuggestionResults
import com.flowlolo.keyboard.latin.utils.WordData
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import kotlin.test.Test

@RunWith(RobolectricTestRunner::class)
class SaveGestureDataTest {
    private val latinIME = Robolectric.setupService(LatinIME::class.java)

    @Test fun allowedWordIsAllowed() {
        val wd = wordData(suggestion("hello", 15, "main"), suggestion("ok", 1, "main"))
        assert(wd.filterSuggestions(emptyList()).size == 1) // only up to the target word / top suggestion
        assert(!wd.isSavingOk(latinIME)) // always fails because dict hash doesn't match
    }

    @Test fun suggestionsAreRedacted() {
        val wd = wordData(suggestion("hello", 15), suggestion("ok", 1, "main"), suggestion("other", 0, "main"))
        wd.targetWord = "ok"
        val filtered = wd.filterSuggestions(emptyList())
        assert(filtered.size == 2)
        assert(filtered[0].word == "")
    }

    @Test fun blockedWordIsFiltered() {
        val wd = wordData(suggestion("hello", 15, "main"), suggestion("ok", 1, "main"))
        assert(wd.filterSuggestions(listOf("hello")).none { it.word.equals("hello", true) })
        assert(!wd.isSavingOk(latinIME)) // always fails because dict hash doesn't match
    }

    private fun suggestion(word: String, score: Int = 0, dict: String = "") =
        SuggestedWordInfo(word, "", score, 0, Dictionary.PhonyDictionary(dict), 0, 0)

    private fun wordData(vararg suggestions: SuggestedWordInfo) =
        WordData(
            null,
            SuggestionResults(18, NgramContext.EMPTY_PREV_WORDS_INFO, false).apply {
                suggestions.forEach { add(it) }
            },
            cd, NgramContext.EMPTY_PREV_WORDS_INFO, kb, InputStyle.NONE, false,
            suggestions.firstOrNull()
        )

    private val cd = ComposedData(InputPointers(1), false, "")

    private val kb = Keyboard(KeyboardParams().apply {
        GRID_HEIGHT = 1
        GRID_WIDTH = 1
        mId = KeyboardLayoutSet.getFakeKeyboardId(KeyboardElement.ALPHABET)
    })
}
