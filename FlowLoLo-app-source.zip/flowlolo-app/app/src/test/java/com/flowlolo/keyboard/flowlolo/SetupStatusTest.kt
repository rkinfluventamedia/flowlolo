package com.flowlolo.keyboard.flowlolo

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SetupStatusTest {

    private val pkg = "com.flowlolo.keyboard"

    @Test
    fun enabled_detectedFromSystemList() {
        val list = "com.google.android.inputmethod.latin/.LatinIME:com.flowlolo.keyboard/.latin.LatinIME:com.other/.Ime"
        assertTrue(SetupStatus.isKeyboardEnabled(list, pkg))
    }

    @Test
    fun notEnabled_whenMissing() {
        val list = "com.google.android.inputmethod.latin/.LatinIME:com.other/.Ime"
        assertFalse(SetupStatus.isKeyboardEnabled(list, pkg))
    }

    @Test
    fun selected_detectedFromDefaultIme() {
        assertTrue(SetupStatus.isKeyboardSelected("$pkg/.latin.LatinIME", pkg))
    }

    @Test
    fun notSelected_whenOtherKeyboardActive() {
        assertFalse(SetupStatus.isKeyboardSelected("com.google.android.inputmethod.latin/.LatinIME", pkg))
    }

    @Test
    fun notSelected_whenNullOrBlank() {
        assertFalse(SetupStatus.isKeyboardSelected(null, pkg))
        assertFalse(SetupStatus.isKeyboardSelected("", pkg))
    }

    @Test
    fun compute_fullJourney() {
        val enabled = "$pkg/.latin.LatinIME"
        // step 1 done only
        var state = SetupStatus.compute(enabled, null, pkg)
        assertFalse(state.allDone)
        assertTrue(state.enabledInSystem)
        // step 2 done too
        state = SetupStatus.compute(enabled, "$pkg/.latin.LatinIME", pkg)
        assertTrue(state.allDone)
        // nothing done
        state = SetupStatus.compute("", null, pkg)
        assertFalse(state.enabledInSystem)
        assertFalse(state.selectedAsCurrent)
    }

    @Test
    fun config_toolbarOrderUnchanged() {
        assertEquals(FlowLoLoConfig.ToolbarItem.MIC, FlowLoLoConfig.TOOLBAR_ITEMS[2])
    }
}
