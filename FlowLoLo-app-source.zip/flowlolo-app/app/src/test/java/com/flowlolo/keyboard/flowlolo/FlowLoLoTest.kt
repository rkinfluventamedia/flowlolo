package com.flowlolo.keyboard.flowlolo

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FlowLoLoTest {

    @Test
    fun config_toolbarHasFiveItemsWithMicCentre() {
        assertEquals(5, FlowLoLoConfig.TOOLBAR_ITEMS.size)
        assertEquals(FlowLoLoConfig.ToolbarItem.MIC, FlowLoLoConfig.TOOLBAR_ITEMS[2])
    }

    @Test
    fun config_sizesInDp() {
        assertEquals(42, FlowLoLoConfig.KEY_HEIGHT_DP)
        assertEquals(300, FlowLoLoConfig.HEIGHT_NORMAL_DP)
    }

    @Test
    fun rkProfileDefaultHasContact() {
        val p = BusinessProfile.defaultRk()
        assertTrue(p.signature.contains("6205557860"))
        assertTrue(p.llm_system_prompt_short.contains("RK INFLUVENTA MEDIA"))
    }

    @Test
    fun rkTemplateTriggerMatches() {
        assertEquals("brand_outreach", RkTemplates.matchTrigger("brand outreach bolo"))
        assertEquals("payment_reminder", RkTemplates.matchTrigger("payment reminder bhejo"))
        assertNotNull(RkTemplates.matchTrigger("creator DM likho"))
    }

    @Test
    fun engineRouterOfflineOnlyBlocksOnline() {
        val router = EngineRouter(offlineOnly = true)
        assertEquals(false, router.canUseOnline())
    }
}
