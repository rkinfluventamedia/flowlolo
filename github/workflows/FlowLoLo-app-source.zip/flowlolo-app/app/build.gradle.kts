import com.android.build.api.variant.ApplicationVariant

plugins {
    id("com.android.application")
    kotlin("plugin.serialization") version "2.4.0"
    kotlin("plugin.compose") version "2.4.0"
}

android {
    // compileSdk 36 (Android 16): phone-IDE safe.
    // WHY NOT 37: Google ka naya platform naming "37.0" hai (minor-version scheme).
    // Android Code Studio (com.tom.rv2ide) ka apna ApiVersionsParser
    // Integer.parseInt("37.0") pe crash hota hai -> "Project Setup Failed:
    // For input string: \"37.0\"". Platform 36 (android-36) plain integer hai ->
    // IDE parser theek. targetSdk bhi 36 = Android 16 (current stable).
    compileSdk = 36

    defaultConfig {
        applicationId = "com.flowlolo.keyboard"
        // Android 8.0+ (API 26): modern platform — adaptive icons, notification channels,
        // all Compose/Material3 features native. Older Android 5-7 compat paths unnecessary.
        // (Owner decision: light + fast + latest APIs; own phone is Android 14.)
        minSdk = 26
        // Android 16 (API 36): current stable target — Play-policy compliant for 2026.
        // compileSdk = 36 bhi (phone-IDE compatibility — see comment above).
        targetSdk = 36
        versionCode = 2
        versionName = "0.2.0-flowlolo"
        ndk {
            abiFilters.clear()
            // PACKAGED native libs: arm64 (64-bit) + armv7 (32-bit) — dono real-phone ABIs.
            // .so files are PREBUILT in jniLibs (no NDK needed at build time).
            // Emulator chalana ho to is list mein "x86_64" add karo AND x86_64 .so build karo.
            abiFilters.addAll(listOf("arm64-v8a", "armeabi-v7a"))
        }
        // LIGHT APK #2: only the languages FlowLoLo ships (PRD: English + Hindi).
        // Trims ~80 other locale strings from libraries.
        // NOTE: agar kisi IDE mein yeh block error de to sirf yeh 3 lines hata dena —
        // APK phir bhi banega, bas thoda bada hoga.
        androidResources {
            localeFilters.addAll(listOf("en", "hi"))
        }
        proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = false
            isDebuggable = false
            isJniDebuggable = false
        }
        create("nouserlib") { // same as release, but does not allow the user to provide a library
            isMinifyEnabled = true
            isShrinkResources = false
            isDebuggable = false
            isJniDebuggable = false
        }
        debug {
            // NOTE: debuggable builds par AGP minify/obfuscation phir bhi disable karta hai
            // (warning ke bare mein: "All code optimizations and obfuscation are disabled
            // for debuggable builds"). Isliye yahan flag false rakha — output SAME, warning gayi.
            isMinifyEnabled = false
            isJniDebuggable = false
            applicationIdSuffix = ".debug"
        }
        create("runTests") { // build variant for running tests on CI that skips tests known to fail
            isMinifyEnabled = false
            isJniDebuggable = false
        }
        create("debugNoMinify") { // for faster builds in IDE
            isDebuggable = true
            isMinifyEnabled = false
            isJniDebuggable = false
            signingConfig = signingConfigs.getByName("debug")
            applicationIdSuffix = ".debug"
            //isDefault = true // would be nice as default, but breaks unit test handling in Android Studio
        }

        androidComponents.onVariants { variant: ApplicationVariant ->
            if (variant.buildType == "debug") {
                // got a little too big for GitHub after some dependency upgrades, so we remove the largest dictionary
                variant.androidResources.ignoreAssetsPatterns = listOf("main_ro.dict")
                variant.proguardFiles = emptyList()
                //noinspection ProguardAndroidTxtUsage we intentionally use the "normal" file here
                variant.proguardFiles.add(project.layout.buildDirectory.file(project.buildFile.parent + "/dontoptimize.pro"))
                variant.proguardFiles.add(project.layout.buildDirectory.file(project.buildFile.parent + "/proguard-rules.pro"))
            }
            variant.outputs.forEach { output ->
                if (output is com.android.build.api.variant.impl.VariantOutputImpl) {
                    output.outputFileName = "FlowLoLo_${defaultConfig.versionName}-${variant.buildType}.apk"
                }
            }
        }
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
        compose = true
    }

    // NATIVE CODE: PREBUILT (no NDK needed on the build machine!)
    // libjni_latinime.so for arm64-v8a + armeabi-v7a lives in app/src/main/jniLibs/.
    // It was compiled from app/src/main/jni/ sources with NDK r28b for APP_PLATFORM=android-26.
    // Phone IDEs (rv2ide / Android Code Studio) no longer run ndk-build -> no CXX1429,
    // no "build/ndk-build: No such file or directory", no NDK download needed.
    // To rebuild the native library later (desktop/CI):
    //   $NDK/ndk-build NDK_PROJECT_PATH=null \
    //     APP_BUILD_SCRIPT=app/src/main/jni/Android.mk \
    //     NDK_APPLICATION_MK=app/src/main/jni/Application.mk \
    //     APP_ABI="arm64-v8a armeabi-v7a" NDK_DEBUG=0 APP_PLATFORM=android-26 \
    //     NDK_OUT=<out> NDK_LIBS_OUT=<libs> -j4
    //   then copy <libs>/<abi>/libjni_latinime.so into app/src/main/jniLibs/<abi>/
    // (externalNativeBuild { ndkBuild { ... } } block intentionally removed.)

    packaging {
        jniLibs {
            // shrinks APK by 3 MB, zipped size unchanged
            useLegacyPackaging = true
        }
    }

    testOptions {
        unitTests {
            isIncludeAndroidResources = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    // see https://github.com/HeliBorg/HeliBoard/issues/477
    dependenciesInfo {
        includeInApk = false
        includeInBundle = false
    }

    namespace = "com.flowlolo.keyboard.latin"
    lint {
        abortOnError = true
    }
}

dependencies {
    // androidx
    implementation("androidx.core:core-ktx:1.17.0") // 1.18.0 requires minSdk 23
    implementation("androidx.recyclerview:recyclerview:1.4.0")
    implementation("androidx.autofill:autofill:1.3.0")
    implementation("androidx.viewpager2:viewpager2:1.1.0")

    // kotlin
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.11.0")

    // compose
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")
    implementation(platform("androidx.compose:compose-bom:2025.11.01")) // newer requires minSdk 23
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
    "debugNoMinifyImplementation"("androidx.compose.ui:ui-tooling")
    implementation("androidx.navigation:navigation-compose:2.9.8")
    implementation("sh.calvin.reorderable:reorderable:3.1.0") // for easier re-ordering
    implementation("com.github.skydoves:colorpicker-compose:1.1.3") // for user-defined colors, newer requires minSdk 23

    // test
    testImplementation(kotlin("test"))
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlin:kotlin-test-junit")
    testImplementation("org.mockito:mockito-core:5.23.0")
    testImplementation("org.robolectric:robolectric:4.16.1")
    testImplementation("androidx.test:runner:1.7.0")
    testImplementation("androidx.test:core:1.7.0")
}
